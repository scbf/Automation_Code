package com.w2a.rough;

import java.awt.AWTException;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.w2a.base.*;
import com.w2a.products.*;
import com.w2a.Categories.*;
import com.w2a.addingNewProducts.*;

public class LoginTest {

	public static void main(String[] args) throws InterruptedException, IOException, AWTException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		/*
		 * HomePage HPage = new HomePage(driver); HPage.userLogin();
		 */
		LoginPage LPage = new LoginPage(driver);
		WorkingOnProducts WPpage = new WorkingOnProducts(driver);
		AddingDiscriptions ADPage = new AddingDiscriptions(driver);
		addOn APage = new addOn(driver);
		fileOperations FOPage = new fileOperations(driver);
		FirstPage FPPage = new FirstPage(driver);
		SecondPage SPPage = new SecondPage(driver);
		ThirdPage TPPage = new ThirdPage(driver);
		AddingCategories ACPage = new AddingCategories(driver);

		LPage.doLogin("robertjames@gmail.com", "123456");
		// Adding the Categories
		WPpage.gotoMenuManagement();
		//WPpage.gotoAddMenu("Pizza Menu","Viz");
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		ACPage.clkOnAddCategories();
		ACPage.enterCategoryDetails("Veg-Corner",
				"This corner contains all the delicacies that are especially entitled and curated for veggie lovers.",
				"Veg - corner section is prepared especially without including any ingredients that are in common with other non veg items or egg items.",
				"1");
		ACPage.addingCatImages("C:\\Users\\Admin\\Downloads\\Veg_Corner.jpg");
		ACPage.clkOnCatSaveBtn();
		Thread.sleep(4000);

		// Adding the Second Category
		ACPage.clkOnAddCategories();
		ACPage.enterCategoryDetails("Non-veg corner",
				"This corner is especially curated for the non vegetarian lovers. Each Item in this section is prepared with the tender meat that is freshly prepared.... Show more",
				"Non Vegetarian corner consists of only three or limited types of meat types. but the most available is the chicken",
				"2");
		ACPage.addingCatImages("C:\\Users\\Admin\\Downloads\\Non_Veg_Corner.jpg");
		ACPage.clkOnCatSaveBtn();
		Thread.sleep(4000);

		// Adding the Third Category
		ACPage.clkOnAddCategories();
		ACPage.enterCategoryDetails("Egg-corner",
				"This corner is specially curated for those egg lovers who is in love nothing else except egg ",
				"Egg dishes are made mostly with fine butter and olive oil, which are a fine items with a lot of healthy benefits",
				"3");
		ACPage.addingCatImages("C:\\Users\\Admin\\Downloads\\Egg_Corner.jpg");
		ACPage.clkOnCatSaveBtn();
		Thread.sleep(4000);

		// Adding the Fourth Category
		ACPage.clkOnAddCategories();
		ACPage.enterCategoryDetails("Extra's",
				" The extras contain the remaining items that are supplements with the main sections.",
				"This section contains some decent items that are paired with the main sections.", "4");
		ACPage.addingCatImages("C:\\Users\\Admin\\Downloads\\Extras.jpg");
		ACPage.clkOnCatSaveBtn();
		Thread.sleep(4000);
		
		// Adding the products into the first Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		WPpage.gotoFirstCategory();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		// Adding the first product
		WPpage.addOnProducts("Paneer Tikka", "20", "1", "3", "100", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\paneer_tikka.jpg");
		WPpage.clkOnFirstCatProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Paneer Tikka is a traditional starter for the veggies. Prepared with an fresh paneer, along with fine quality other ingredients");
		ADPage.addOnSecondDiscription(
				"بانير تيكا هو مقبلات تقليدية للخضروات. محضرة من بانير طازج مع مكونات أخرى عالية الجودة");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Green Chutney", "1");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Adding the second Product
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		WPpage.gotoFirstCategory();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Mushroom Fry", "30", "1", "5", "100", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\mushroom_fry.jpg");
		WPpage.clkOnFirstCatProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Being one of the most favored item for the veggies, mushroom fry contains a lot of ingredients that are beneficail to health.");
		ADPage.addOnSecondDiscription(
				"كونها واحدة من أكثر العناصر المفضلة للخضار ، تحتوي فراي الفطر على الكثير من المكونات المفيدة للصحة.");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Extra Mushroom", "5");
		APage.clkOnaddOnSaveBtn();

		// Adding the third product
		Thread.sleep(5000);
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		WPpage.gotoCategories();

		WPpage.gotoFirstCategory();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Veg Biryani", "50", "1", "5", "250", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\veg_biryani.jpg");
		WPpage.clkOnFirstCatProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription("Veg biryani includes of 55 ingredients with a cal rate of 100/ 150 gm of rice.");
		ADPage.addOnSecondDiscription("البرياني النباتي يحتوي على 55 مكونًا بمعدل سعرات حرارية 100/150 جرام من الأرز.");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Raita", "2");
		APage.clkOnaddOnSaveBtn();

		Thread.sleep(5000);
		// Adding the fourth Product;
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		WPpage.gotoFirstCategory();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Lassi - Special", "15", "1", "3", "250", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\lassi_special.jpg");
		WPpage.clkOnFirstCatProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"The favourite sweet drink that everyone carves right after their heavy meals -  we have some other special ingredients that are mixed in to make our customers crave for it even more.");
		ADPage.addOnSecondDiscription(
				"المشروب الحلو المفضل الذي يحفره الجميع مباشرة بعد وجباتهم الثقيلة - لدينا بعض المكونات الخاصة الأخرى التي يتم مزجها لجعل عملائنا يتوقون إليها أكثر.");
		Thread.sleep(2000);
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Extra Sugar", "1");
		APage.clkOnaddOnSaveBtn();

		Thread.sleep(5000);
		// Adding the fifth Product;
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		WPpage.gotoFirstCategory();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Rice Wine", "25", "1", "3", "250", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Rice_Wine.jpg");
		WPpage.clkOnFirstCatProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Rice wine is the favorite wine that many east asians still brewing to this day on their homes. This wine here is brewed by our own chef.");
		ADPage.addOnSecondDiscription(
				"نبيذ Rcie هو النبيذ المفضل الذي لا يزال العديد من الآسيويين الشرقيين يخمرونه حتى يومنا هذا في منازلهم. يتم تخمير هذا النبيذ هنا من قبل طاهينا الخاص.");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Extra Sugar", "1");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Now adding products on second category
		WPpage.gotoMenuManagement();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		FPPage.gotoSecondCategory();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Chicken Tikka", "30", "1", "4", "500", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Chicken_Tikka.jpg");
		FPPage.clkOnSecondCategory();
		FPPage.clkOnSecondProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Chicken Tikka is made by placing the chicken on the kadai under the grill. The crispness of this chicken tikka that has been made here is one of the best.");
		ADPage.addOnSecondDiscription(
				"يتم تحضير دجاج تكا عن طريق وضع الدجاج على كادي تحت الشواية. إن هشاشة تكا الدجاج التي تم صنعها هنا هي واحدة من الأفضل.");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Green Chutney", "1");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);
		// Adding the Second Production Second Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		FPPage.gotoSecondCategory();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Fish Fry", "30", "1", "4", "500", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Fish_Fry.jpg");
		FPPage.clkOnSecondCategory();
		FPPage.clkOnSecondProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"The Fishes that we use here are one of the best in the entire city. The fry that we made is neither hard not so soft, but the mellow creaminess that will come along the mix is the best in the town");
		ADPage.addOnSecondDiscription(
				"الأسماك التي نستخدمها هنا هي واحدة من أفضل الأسماك في المدينة بأكملها. الزريعة التي صنعناها ليست صلبة وليست ناعمة جدًا ، لكن الدسم اللطيف الذي سيأتي مع المزيج هو الأفضل في المدينة");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Raita", "2");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Adding the Third Product secoond Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		FPPage.gotoSecondCategory();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Mixed Biryani", "30", "1", "4", "500", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Mixed_Biryani.jpg");
		FPPage.clkOnSecondCategory();
		FPPage.clkOnSecondProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Mixed Nonveg biryani is made of chicken,mutton, eggs and prawns. The heavy biryani consists a lot of calories that will make you feel bliss in satisfaction.");
		Thread.sleep(2000);
		ADPage.addOnSecondDiscription(
				"خليط نونفيج برياني مصنوع من الدجاج ولحم الضأن والبيض والقريدس. البرياني الثقيل يحتوي على الكثير من السعرات الحرارية التي ستجعلك تشعر بالرضا.");
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Raita", "2");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Adding fourth Product into the second Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		FPPage.gotoSecondCategory();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Rum Wine", "30", "1", "2", "100", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Rum_Wine.jpg");
		FPPage.clkOnSecondCategory();
		FPPage.clkOnSecondProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"The favorite rum wine that is present in our assests with years fo concoting. This fine rum will light up the mood and set the festive mode on the room.");
		ADPage.addOnSecondDiscription(
				"نبيذ الروم المفضل الموجود في شركائنا منذ سنوات طويلة. سوف يضيء هذا الروم الرائع المزاج ويضبط الوضع الاحتفالي في الغرفة.");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Pickle", "1");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Adding first Product into the Third Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		SPPage.gotoThirdCategory();
		SPPage.gotoProducts();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Egg Bhurji", "22", "1", "2", "100", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Egg_Burji.jpg");
		SPPage.clkOnThirdVatCategory();
		SPPage.clkOnThirdProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Egg Bhurji is must start for many of the egg lovers in the world. This egg bhurji consists of finely battered 3 eggs along with many other healthy ingredients.");
		ADPage.addOnSecondDiscription(
				"يجب أن يبدأ Egg Bhurji بالنسبة للعديد من محبي البيض في العالم. يتكون برجي البيض هذا من 3 بيضات مسلوقة جيدًا مع العديد من المكونات الصحية الأخرى.");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Chilli & Onions", "3");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Adding the Second Product into the Third Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		SPPage.gotoThirdCategory();
		SPPage.gotoProducts();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Omelette", "10", "1", "2", "100", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Omlete.jpg");
		SPPage.clkOnThirdVatCategory();
		SPPage.clkOnThirdProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Omlette the most famous dish that any egg lover cannot deny. This omlette is made of 4 eggs, which is not a norm. But that is the speciality of our chef here. Once trying this that you will never like other items");
		ADPage.addOnSecondDiscription(
				"أومليت هو أشهر طبق لا يستطيع أي محب للبيض إنكاره. يتكون هذا البيض من 4 بيضات ، وهذا ليس معيارًا. لكن هذا هو اختصاص طاهينا هنا. بمجرد تجربة هذا ، لن تحب العناصر الأخرى أبدًا");
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Mayo", "2");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Adding the Third Product into the Third Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		SPPage.gotoThirdCategory();
		SPPage.gotoProducts();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Surat Egg curry", "55", "1", "5", "100", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Surat_Egg_Curry.jpg");
		SPPage.clkOnThirdVatCategory();
		SPPage.clkOnThirdProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Surat is famous for it delicious egg dishes all around the world. Our this surat egg curry is made with 3 boiled eggs is one of the finest egg items that we can offer in our restaurant.");
		ADPage.addOnSecondDiscription(
				"تشتهر سورات بأطباق البيض اللذيذة في جميع أنحاء العالم. يتكون كاري البيض هذا من 3 بيضات مسلوقة وهي واحدة من أجود أنواع البيض التي يمكن أن نقدمها في مطعمنا.");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Onions", "1");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Adding the Fourth Product into the Third Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		SPPage.gotoThirdCategory();
		SPPage.gotoProducts();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Egg biryani", "60", "1", "5", "100", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Egg_Biryani.jpg");
		SPPage.clkOnThirdVatCategory();
		SPPage.clkOnThirdProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Egg biryani is made of the finest spices along with 2 boiled eggs cut into 4 pieces or 2 full eggs, depends on the choice of the day by the chef.");
		ADPage.addOnSecondDiscription(
				"بيض برياني مصنوع من أجود أنواع البهارات مع 2 بيضة مسلوقة مقطعة إلى 4 قطع أو 2 بيضة كاملة ، حسب اختيار اليوم من قبل الشيف.");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("raita", "2");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Adding the Fifth Product into the Third Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		SPPage.gotoThirdCategory();
		SPPage.gotoProducts();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Masala Butter Milk", "12", "1", "5", "100", FOPage.input);
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Masala_Butter_Milk.jpg");
		SPPage.clkOnThirdVatCategory();
		SPPage.clkOnThirdProperties();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"The good old masala chass that is a mandatory for the good digestion after an hearty meal");
		ADPage.addOnSecondDiscription("تشاس ماسالا القديم الجيد الذي يعد إلزاميًا للهضم الجيد بعد تناول وجبة دسمة");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		ADPage.clkOnNextBtn();
		APage.clkOnAddOn();
		APage.clkonAddEntryBtn();
		APage.enterDetails("Extra Masala", "1");
		APage.clkOnaddOnSaveBtn();
		Thread.sleep(5000);

		// Adding the Second Product into the Fourth Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		TPPage.gotoFourthCategory();
		TPPage.gotoProducts();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Butter Roti", "5", "1", "3", "100", FOPage.input);
		TPPage.clkOnThirdProperties();
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Butter_Roti.jpg");
		TPPage.clkOnFourthVatCategory();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription(
				"Butter roti is an item that pairs with any of the items that are available in the menu");
		ADPage.addOnSecondDiscription("الزبدة روتي هي عنصر يتزاوج مع أي من العناصر المتوفرة في القائمة");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		Thread.sleep(5000);

		// Adding the Second Product in the Fourth Category
		WPpage.gotoMenuManagement();
		WPpage.gotoFirstMenu();
		WPpage.gotoCategories();
		TPPage.gotoFourthCategory();
		TPPage.gotoProducts();
		WPpage.gotoProducts();
		WPpage.clkOnNewProduct();
		FOPage.handlingDataFromFile();
		WPpage.addOnProducts("Pav", "3", "1", "3", "100", FOPage.input);
		TPPage.clkOnThirdProperties();
		WPpage.addImagetoProduct("C:\\Users\\Admin\\Downloads\\Pav.jpg");
		TPPage.clkOnFourthVatCategory();
		WPpage.clkOnFirstCatSaveBtn();
		ADPage.addOnFirstDiscription("Pav is a must item for the egg section");
		ADPage.addOnSecondDiscription("يعتبر Pav عنصرًا ضروريًا لقسم البيض");
		Thread.sleep(2000);
		ADPage.clkOnadsSaveBtn();
		Thread.sleep(5000);

	}

}
