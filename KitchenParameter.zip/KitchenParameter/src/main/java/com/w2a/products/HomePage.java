package com.w2a.products;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

	WebDriver driver;
	
	public HomePage(WebDriver driver) {
		
	this.driver = driver;
	}

	public void userLogin() {

		driver.findElement(By.name("email")).sendKeys("robertjames@gmail.com");

		driver.findElement(By.name("password")).sendKeys("123456");

		driver.findElement(By.xpath("//button[@class='btn btn-lg btn-primary w-100 mb-5']")).click();
	}

}
