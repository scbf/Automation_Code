package com.w2a.products;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class AddingDiscriptions {

	public WebDriver driver;

	public AddingDiscriptions(WebDriver driver) {

		this.driver = driver;
	}

	public void addOnFirstDiscription(String Discription) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,-500)");
		Thread.sleep(2000);
		// WebElement iframeID =
		// driver.findElement(By.id("tiny-react_54550395121688104623716_ifr"));
		driver.switchTo().frame(driver.findElement(By.xpath(
				"/html/body/div[1]/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/div/div[1]/div/div[1]/div/div[1]/div[2]/div[1]/iframe")));
		driver.findElement(By.tagName("p")).sendKeys(Discription);
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath(
				"/html/body/div[1]/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/div/div[1]/div[1]/div[3]/button"))
				.click();
		// jse.executeScript("window.scrollBy(0,250)");
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		jse.executeScript("window.scrollBy(0,500)");
	}

	public void addOnSecondDiscription(String anotherDiscription) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.switchTo().frame(driver.findElement(By.xpath(
				"/html/body/div[1]/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/div/div/div[2]/div[1]/div/div[1]/div[2]/div[1]/iframe")));

		driver.findElement(By.xpath("/html/body/p")).sendKeys(anotherDiscription);
		driver.switchTo().parentFrame();
	}

	public void clkOnadsSaveBtn() throws InterruptedException {
		driver.findElement(By.xpath(
				"/html/body/div[1]/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/div/div/div[2]/div[3]/button"))
				.click();
		Thread.sleep(2000);
	}

	public void clkOnNextBtn() throws InterruptedException {
		Thread.sleep(2000);
		driver.navigate().refresh();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(500,1000)");
		Thread.sleep(2000);
		driver.findElement(By
				.xpath("/html/body/div[1]/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/div/div[2]/button"))
				.sendKeys(Keys.RETURN);

	}
}
