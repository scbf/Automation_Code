package com.w2a.products;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class addOn {

	WebDriver driver;

	public addOn(WebDriver driver) {

		this.driver = driver;
	}

	public void clkOnAddOn() {

		driver.findElement(By.linkText("Add On")).click();
	}

	public void clkonAddEntryBtn() {

		driver.findElement(By.xpath("//button[@class='btn btn-primary addtimes']")).click();
	}

	public void enterDetails(String ingredients, String amount) {

		driver.findElement(By.xpath("//input[@class='form-control form-control-solid']")).sendKeys(ingredients);

		driver.findElement(By.xpath("//input[@class='filterme form-control form-control-solid']")).sendKeys(amount);

	}

	public void clkOnaddOnSaveBtn() throws InterruptedException {

		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='indicator-label']")).click();

	}
}
