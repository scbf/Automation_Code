package com.w2a.products;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WorkingOnProducts {

	WebDriver driver;

	public WorkingOnProducts(WebDriver driver) {

		this.driver = driver;
	}

	public void gotoMenuManagement() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.findElement(By.partialLinkText("Menu Management")).click();
	}

	public void gotoAddMenu(String menuName, String menuValue) throws InterruptedException, AWTException {
		driver.findElement(By.linkText("Add New Menu")).click();

		driver.findElement(By.xpath("//input[@class='form-control form-control-solid']")).sendKeys(menuName);

		driver.findElement(By.xpath("//div[@class=' css-ackcql']")).click();


		Robot rb = new Robot();
		rb.delay(3000);

		StringSelection ss = new StringSelection(menuValue);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);

		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);

		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
	}

	public void gotoFirstMenu() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div/div/div/div/div/a/h5")).click();
	}

	public void gotoCategories() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.linkText("Categories")).click();
	}

	public void gotoFirstCategory() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Veg-Corner")).click();
	}

	public void gotoProducts() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-100)");
		driver.findElement(By.linkText("Products")).click();
		Thread.sleep(2000);
		/*
		 * String pText = driver.findElement(By.xpath("//div/div/a/b")).getText();
		 * System.out.println(pText); if(pText.equals("No Product Found.")) {
		 * 
		 * driver.findElement(By.xpath("//button[@class='btn btn-primary ps-7']")).click
		 * (); }
		 */
	}

	public void clkOnNewProduct() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.findElement(By.xpath("//button[@class='btn btn-primary ps-7']")).click();
	}

	public void addOnProducts(String pName, String bPrice, String minQuantity, String maxQuantity, String stock,
			String sequelNumber) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[1]/div/div[1]/div[1]/div[2]/input"))
				.sendKeys(pName);

		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[1]/div/div[2]/div[4]/div[2]/input"))
				.sendKeys(bPrice);

		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[1]/div/div[1]/div[3]/div[2]/input"))
				.sendKeys(minQuantity);

		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[1]/div/div[1]/div[3]/div[3]/input"))
				.sendKeys(maxQuantity);

		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[1]/div/div[2]/div[5]/div[2]/input"))
				.sendKeys(stock);

		if (pName == "Paneer Tikka" || pName == "Mushroom Fry" || pName == "Veg Biryani" || pName == "Lassi - Special"
				|| pName == "Rice Wine") {
			WebElement VATcategory = driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[2]/div/div[1]/div/div/select"));
			Select select = new Select(VATcategory);
			select.selectByIndex(1);

		} else if (pName == "Chicken Tikka" || pName == "Fish Fry" || pName == "Mixed Biryani" || pName == "Rum Wine") {
			WebElement VATcategory = driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[2]/div/div[1]/div/div/select"));
			Select select = new Select(VATcategory);
			select.selectByIndex(2);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[2]/div/div[2]/div/div/input"))
				.sendKeys(sequelNumber);
	}

	public void addImagetoProduct(String imageLocation) throws InterruptedException, AWTException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,-250)");
		Thread.sleep(2000);
		WebElement imageBtn = driver.findElement(By.xpath("//i[@class='bi bi-pencil-fill fs-7']"));
		imageBtn.click();

		Robot rb = new Robot();
		rb.delay(3000);

		StringSelection ss = new StringSelection(imageLocation);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);

		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);

		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		// driver.findElement(By.xpath("//i[@class='bi bi-pencil-fill
		// fs-7']")).sendKeys(imageLocation);
	}

	public void clkOnFirstCatProperties() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[3]/div/div[2]/div[1]/input"))
				.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[3]/div/div[2]/div[8]/input"))
				.click();
		Thread.sleep(2000);
		// driver.findElement(By.xpath("//span[@class='indicator-label']")).click();

	}

	public void clkOnFirstCatSaveBtn() {

		driver.findElement(By.xpath("//span[@class='indicator-label']")).click();
	}
}
