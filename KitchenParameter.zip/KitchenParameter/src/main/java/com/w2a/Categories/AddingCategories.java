package com.w2a.Categories;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AddingCategories {

	WebDriver driver;

	public AddingCategories(WebDriver driver) {
		this.driver = driver;
	}
	
	public void clkOnAddCategories() throws InterruptedException {
		
		driver.findElement(By.linkText("Add Category")).click();
		Thread.sleep(2000);
	}
	
	public void enterCategoryDetails(String catName, String Discription, String Disclaimer, String seqNumber) throws InterruptedException {
		
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/div/form/div/div[2]/div[1]/div[2]/input"))
				.sendKeys(catName);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/div/form/div/div[3]/div[1]/div[2]/input"))
				.sendKeys(Discription);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"kt_tab_pane_1\"]/div/div/form/div/div[2]/div[2]/div[2]/input"))
				.sendKeys(Disclaimer);
		
		driver.findElement(By.xpath("//*[@id=\"kt_tab_pane_1\"]/div/div/form/div/div[3]/div[2]/div[1]/input"))
		.sendKeys(seqNumber);
		Thread.sleep(2000);
		
	}
	public void addingCatImages(String imageLocation) throws InterruptedException, AWTException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,-100)");
		Thread.sleep(2000);
		WebElement imageBtn = driver.findElement(By.xpath("//i[@class='bi bi-pencil-fill fs-7']"));
		imageBtn.click();

		Robot rb = new Robot();
		rb.delay(3000);

		StringSelection ss = new StringSelection(imageLocation);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);

		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);

		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		// driver.findElement(By.xpath("//i[@class='bi bi-pencil-fill
		// fs-7']")).sendKeys(imageLocation);
	}
	public void clkOnCatSaveBtn() throws InterruptedException {
		driver.findElement(By.id("kt_modal_new_address_submit")).click();
		Thread.sleep(5000);
	}
}
