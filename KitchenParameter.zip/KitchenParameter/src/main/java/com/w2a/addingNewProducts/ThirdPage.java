package com.w2a.addingNewProducts;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ThirdPage {

	WebDriver driver;

	public ThirdPage(WebDriver driver) {

		this.driver = driver;
	}

	public void gotoFourthCategory() throws InterruptedException {

		driver.findElement(By.partialLinkText("Extra's")).click();
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,-1000)");
		Thread.sleep(3000);
	}

	public void gotoProducts() {

		driver.findElement(By.linkText("Products")).click();
	}

	public void clkOnNewProductBtnFCat() {

		driver.findElement(By.xpath("//button[@class='btn btn-primary ps-7']")).click();
	}

	public void clkOnFourthVatCategory() {

		WebElement VATcategory = driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[2]/div/div[1]/div/div/select"));
		Select select = new Select(VATcategory);
		select.selectByIndex(1);

	}

	public void clkOnThirdProperties() {

		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[3]/div/div[2]/div[3]/input"))
				.click();

		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div/div/div/form/div[3]/div/div[2]/div[8]/input"))
				.click();
	}

}
