package com.w2a.base;

import java.io.*;

import org.openqa.selenium.WebDriver;

public class fileOperations {

	public String input;
	WebDriver driver;

	public fileOperations(WebDriver driver) {

		this.driver = driver;

	}

	public void handlingDataFromFile() throws IOException {

		File file = new File("C:\\Users\\Admin\\Downloads\\KitchenParameter\\KitchenParameter\\KitchenParameter\\Files\\samples.txt");

		BufferedReader Freader = new BufferedReader(new FileReader(file));

		input = Freader.readLine();

		System.out.println("User getting String is : " + input);

		Freader.close();

		int myText = Integer.parseInt(input);
		// Now Writing on the File
		myText++;
		BufferedWriter Fwriter = new BufferedWriter(new FileWriter(file, false));
		Fwriter.flush();
		Fwriter.write(Integer.toString(myText));
		Fwriter.close();
	}
}
