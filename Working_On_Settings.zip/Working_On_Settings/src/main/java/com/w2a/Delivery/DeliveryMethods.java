package com.w2a.Delivery;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.w2a.AllVariableValus;

public class DeliveryMethods {

	AllVariableValus values = new AllVariableValus();

	WebDriver driver;

	public DeliveryMethods(WebDriver driver) {

		this.driver = driver;
	}

	public void clkOnSettings() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement deliveryBtn = driver.findElement(By.xpath("(//div/a)[11]"));
		Actions action = new Actions(driver);
		action.moveToElement(deliveryBtn).perform();
		deliveryBtn.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div/a/div/center/div)[1]")).click();
		Thread.sleep(5000);
	}

	public void clkOnBranchSltn(String branchName) throws AWTException, InterruptedException {

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		WebElement branchSelection = driver.findElement(By.xpath("//div[@class=' css-ackcql']"));
		Actions action = new Actions(driver);
		action.moveToElement(branchSelection).click().sendKeys(branchName).sendKeys(Keys.ENTER).perform();
		Thread.sleep(3000);	

	}

	public void gotoRestaurantManagement(String openTime, String closeTime, String avgMakeTime)
			throws InterruptedException {
		Thread.sleep(5000);
		WebElement deliveryDay = driver.findElement(By.xpath("//select[@class='form-control']"));

		Select select = new Select(deliveryDay);
		select.selectByIndex(9);

		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[1]")).sendKeys(openTime);

		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[2]")).sendKeys(closeTime);

		driver.findElement(By.xpath("(//input[@type='text'])[2]")).sendKeys(avgMakeTime);

		driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[1]")).click();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-1500)", "");

	}

	public void gotoAdtCharges(String name, String levelName, String price) throws InterruptedException {
		try {
			Thread.sleep(5000);

			driver.findElement(By.linkText("Additional Charges")).click();

			driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[1]")).sendKeys(name);

			driver.findElement(By.xpath("//div[@class='mb-10']//button[@id='kt_modal_new_address_submit']")).click();

			Thread.sleep(2000);

			driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[6]")).sendKeys(levelName);

			driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[11]")).sendKeys(price);

			driver.findElement(By.xpath(
					"//div[@class='row']//div[@class='modal-footer flex-center']//button[@id='kt_modal_new_address_submit']"))
					.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-1500)", "");
			driver.findElement(By.linkText("Settings")).click();
		}
	}

	public void addingZones(String meters, String orderQuantity, String deliveryCost, String noDeliveryCost)
			throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-1000)", "");
		driver.findElement(By.linkText("Zones")).click();

		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[3]"))
				.sendKeys(meters);

		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[4]"))
				.sendKeys(orderQuantity);

		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[5]"))
				.sendKeys(deliveryCost);

		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[6]"))
				.sendKeys(noDeliveryCost);

		driver.findElement(By.xpath("(//button[@id='kt_modal_new_address_submit'])[1]")).click();
	}

	public void addSecondZone(String secondZoneMeter, String secondZoneorderQuantity, String secondZonedeliveryCost,
			String secondZoneNoDeliveryCost) throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[7]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[7]"))
				.sendKeys(secondZoneMeter);

		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[8]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[8]"))
				.sendKeys(secondZoneorderQuantity);

		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[9]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[9]"))
				.sendKeys(secondZonedeliveryCost);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[10]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[10]"))
				.sendKeys(secondZoneNoDeliveryCost);

		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[7]")).clear();
		driver.findElement(By.xpath("(//button[@id='kt_modal_new_address_submit'])[2]")).click();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-500)", "");
		boolean a = driver.findElement(By.xpath("//input[@type='checkbox']")).isSelected();
		if (a == false) {
			driver.findElement(By.xpath("//input[@type='checkbox']")).click();
		}
		Thread.sleep(5000);
	}

	public void clkOnSettingsBtn(String email, String orderTime, String orderPerInterval, String orderDays)
			throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-1000)", "");
		driver.findElement(By.linkText("Settings")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form-control form-control-solid']")).clear();
		driver.findElement(By.xpath("//input[@class='form-control form-control-solid']")).sendKeys(email);
		Thread.sleep(2000);
		boolean a = driver.findElement(By.xpath("(//input[@type='checkbox'])[1]")).isSelected();
		if (a == false) {
			driver.findElement(By.xpath("(//input[@type='checkbox'])[1]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[1]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[1]"))
				.sendKeys(orderTime);
		Thread.sleep(2000);
		boolean b = driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).isSelected();
		if (b == false) {
			driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[2]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[2]"))
				.sendKeys(orderPerInterval);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[3]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[3]"))
				.sendKeys(orderDays);
		Thread.sleep(2000);
		boolean c = driver.findElement(By.xpath("(//input[@type='checkbox'])[4]")).isSelected();
		if (c == false) {
			driver.findElement(By.xpath("(//input[@type='checkbox'])[4]")).click();
		}
		Thread.sleep(5000);
	}

	public void clkOnPaymentType() {

		driver.findElement(By.xpath("//button[@id='kt_modal_new_address_submit']")).click();
	}
}
