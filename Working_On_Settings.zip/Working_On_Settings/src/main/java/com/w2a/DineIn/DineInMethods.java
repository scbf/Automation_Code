package com.w2a.DineIn;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class DineInMethods {

	WebDriver driver;

	public DineInMethods(WebDriver driver) {

		this.driver = driver;
	}

	public void clkOnDIneIn() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement deliveryBtn = driver.findElement(By.xpath("(//div/a)[11]"));
		Actions action = new Actions(driver);
		action.moveToElement(deliveryBtn).perform();
		deliveryBtn.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div/a/div/center/div)[5]")).click();
		Thread.sleep(5000);
	}

	public void gotoAdditionalCharges(String name, String levelName, String price) {

		try {
			Thread.sleep(5000);

			driver.findElement(By.linkText("Additional Charges")).click();

			driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[1]")).sendKeys(name);

			driver.findElement(By.xpath("//div[@class='mb-10']//button[@id='kt_modal_new_address_submit']")).click();

			Thread.sleep(2000);

			driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[6]")).sendKeys(levelName);

			driver.findElement(By.xpath("//input[@class='filterme form-control form-control-solid']")).sendKeys(price);
			driver.findElement(By.xpath(
					"//div[@class='row']//div[@class='modal-footer flex-center']//button[@id='kt_modal_new_address_submit']"))
					.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-1500)", "");
			driver.findElement(By.linkText("Settings")).click();
		}
	}

	public void gotoDineInSettings(String email) throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-1100)", "");
		driver.findElement(By.linkText("Settings")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form-control form-control-solid']")).clear();
		driver.findElement(By.xpath("//input[@class='form-control form-control-solid']")).sendKeys(email);
		Thread.sleep(2000);
		boolean a = driver.findElement(By.xpath("(//input[@type='checkbox'])[1]")).isSelected();
		if (a == false) {
			driver.findElement(By.xpath("(//input[@type='checkbox'])[1]")).click();
		}
		Thread.sleep(2000);
		boolean b = driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).isSelected();
		if (b == false) {
			driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
		}
		Thread.sleep(2000);
		boolean c = driver.findElement(By.xpath("(//input[@type='checkbox'])[3]")).isSelected();
		if (c == false) {
			driver.findElement(By.xpath("(//input[@type='checkbox'])[3	]")).click();
		}
	}
}