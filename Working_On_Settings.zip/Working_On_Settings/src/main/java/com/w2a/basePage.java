package com.w2a;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class basePage {
	AllVariableValus values = new AllVariableValus();
	
WebDriver driver;
	public basePage(WebDriver driver) {
		this.driver = driver;
	}
	public void gotoLogin(String email, String password) {
		driver.get("http://www.resgroup.mypreview.xyz/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
		driver.findElement(By.name("email")).sendKeys(email);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.xpath("//button[@class='btn btn-lg btn-primary w-100 mb-5']")).sendKeys(Keys.ENTER);
}
	public void gotoSettings() {
		
	}
}