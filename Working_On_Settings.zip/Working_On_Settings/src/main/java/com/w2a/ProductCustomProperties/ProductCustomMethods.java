package com.w2a.ProductCustomProperties;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class ProductCustomMethods {

	WebDriver driver;

	public ProductCustomMethods(WebDriver driver) {

		this.driver = driver;
	}
	public void gotoCustomProperties() throws InterruptedException {
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement deliveryBtn = driver.findElement(By.xpath("(//div/a)[11]"));
		Actions action = new Actions(driver);
		action.moveToElement(deliveryBtn).perform();
		deliveryBtn.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div/a/div/center/div)[13]")).click();
		Thread.sleep(5000);
	}
	public void enterPropertyDetails() throws InterruptedException {
		
		driver.findElement(By.xpath("(//button[@type='button'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form-input']")).sendKeys("Non-Alcoholic Products");
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[@type='submit'])[1]")).click();
	}
}
