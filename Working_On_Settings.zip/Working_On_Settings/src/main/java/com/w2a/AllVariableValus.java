package com.w2a;

public class AllVariableValus {

	// enter the user login credentials//
	public String email = "Lakadimary@gmail.com";
	public String password = "123456";

	// user entering the restaurant times
	public String branchName = "VizagBranch";
	public String openTime = "1000AM";
	public String closeTime = "1000PM";
	public String avgMakeTime = "15";

	// adding additional charges
	public String mainName = "Golden";
	public String levelName = "Golden Level One";
	public String priceValue = "2";

	// user adding the zones
	public String zone1Meter = "5000";
	public String zone1Minorder = "25";
	public String zone1deliveryCosts = "4";
	public String zone1NodeliveryCosts = "30";

	// user adding the secondZone Details
	public String zone2Meter = "2500";
	public String zone2Minorder = "15";
	public String zone2deliveryCosts = "2";
	public String zone2NodeliveryCosts = "20";

	// User is adding the restaurant details
	public String restaurantEmail = "vizagBranch@gmail.com";
	public String orderingInterval = "15";
	public String orderparticularTime = "50";
	public String orderDaysAdvance = "2";
	public String minimumOrderInpickUp = "30";

	// User is adding the payment provider
	public String customerID = "263539";
	public String terminalID = "17752142";
	public String authorToken = "QVBJXzI2MzUzOV8wNzM4OTI4ODpVN3AxUzJzN2ZRT3VRdGox";

	// user is adding the POSDetails - G Series
	public String businessUnitId = "5712";
	public String waiterId = "112";
	public String deliveryTableNo = "500";
	public String token = "f63b77b24ba81a19a26082d7ae6943e6b6896a5d";
	public String tenderID = "252";
	public String pickUpTableNo = "800";

	// user is adding the VAT Charges
	public String frstVATdelivery = "5";
	public String frstVATpickUp = "3";
	public String frstVATdineIn = "6";

	// user is adding the secondVatCharges
	public String secndVATdelivery = "3";
	public String secndVATpickUp = "4";
	public String secndVATdineIn = "5";

	// user is adding the thrdVatCharges
	public String thrdVATdelivery = "7";
	public String thrdVATpickUp = "4";
	public String thrdVATdineIn = "5";

	// user is adding the GroupDetails
	public String imageLocation = "C:\\Users\\Admin\\Downloads\\RestaurantLogo.jpg";
	public String welcomeMessage = "Welcome to Restaurant";
	public String emailGroup = "vizagBranchJohny@gmail.com";

}
