package com.w2a.POS;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class POSMethods {

	WebDriver driver;

	public POSMethods(WebDriver driver) {
		this.driver = driver;
	}

	public void gotoPOS() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement deliveryBtn = driver.findElement(By.xpath("(//div/a)[11]"));
		Actions action = new Actions(driver);
		action.moveToElement(deliveryBtn).perform();
		deliveryBtn.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div/a/div/center/div)[9]")).click();
		Thread.sleep(5000);
	}
	
	public void clkOnPOSType() {
		
		driver.findElement(By.xpath("(//div[@class='card-body p-2'])[1]")).click();
	}
	public void enterPOSDetails(String businessID, String token, String waiterID, String tenderID, String deliveryTableNo, String pickUpNo) throws InterruptedException {
		
		
		Thread.sleep(2000);
		String activeStatus = driver.findElement(By.xpath("//div[@class='d-flex justify-content-end ']")).getText();
		if(activeStatus.equals("Inactive")) {
			
			driver.findElement(By.xpath("//div[@class='d-flex justify-content-end ']")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form-control form-control-solid'][1]")).clear();
		driver.findElement(By.xpath("//input[@class='form-control form-control-solid'][1]")).sendKeys(businessID);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[2]")).clear();
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[2]")).sendKeys(token);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[3]")).clear();
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[3]")).sendKeys(waiterID);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[4]")).clear();
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[4]")).sendKeys(tenderID);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[5]")).clear();
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[5]")).sendKeys(deliveryTableNo);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[6]")).clear();
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[6]")).sendKeys(pickUpNo);
		Thread.sleep(2000);

		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}
}
