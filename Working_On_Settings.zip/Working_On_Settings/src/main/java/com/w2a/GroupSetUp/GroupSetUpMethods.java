package com.w2a.GroupSetUp;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class GroupSetUpMethods {

	WebDriver driver;

	public GroupSetUpMethods(WebDriver driver) {

		this.driver = driver;
	}

	public void clkOnGroupSetUp() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement deliveryBtn = driver.findElement(By.xpath("(//div/a)[11]"));
		Actions action = new Actions(driver);
		action.moveToElement(deliveryBtn).perform();
		deliveryBtn.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div/a/div/center/div)[15]")).click();
		Thread.sleep(5000);
	}

	public void clkOnImage(String imageLocation) throws AWTException {

		driver.findElement(By.xpath("//i[@class='bi bi-pencil-fill fs-7']")).click();

		Robot rb = new Robot();
		rb.delay(3000);

		StringSelection ss = new StringSelection(imageLocation);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);

		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);

		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
	}

	public void enterOnGroupSetup(String groupMsg, String grpEmail) throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[1]")).clear();
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[1]")).sendKeys(groupMsg);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[6]")).clear();
		driver.findElement(By.xpath("(//input[@class='form-control form-control-solid'])[6]")).sendKeys(grpEmail);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}

}