package com.w2a.VatCharges;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class VatChargesMethods {

	WebDriver driver;

	public VatChargesMethods(WebDriver driver) {

		this.driver = driver;
	}

	public void clkOnVatCharges() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement deliveryBtn = driver.findElement(By.xpath("(//div/a)[11]"));
		Actions action = new Actions(driver);
		action.moveToElement(deliveryBtn).perform();
		deliveryBtn.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div/a/div/center/div)[11]")).click();
		Thread.sleep(5000);
	}
	public void enterFirstCatVatCharges(String frstDelValue, String frstPickUpValue, String frstDineInValue) throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[1]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[1]")).sendKeys(frstDelValue);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[2]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[2]")).sendKeys(frstPickUpValue);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[3]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[3]")).sendKeys(frstDineInValue);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[@type=\"submit\"])[1]")).click();
		
	}
	public void enterSecondCatVatCharges(String secDelValue, String secPickUpValue, String secDineInValue) throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[4]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[4]")).sendKeys(secDelValue);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[5]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[5]")).sendKeys(secPickUpValue);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[6]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[6]")).sendKeys(secDineInValue);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[@type=\"submit\"])[2]")).click();
		
	}
	public void enterThridCatVatCharges(String thrdDelValue, String thrdPickUpValue, String thrdDineInValue) throws InterruptedException {
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[7]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[7]")).sendKeys(thrdDelValue);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[8]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[8]")).sendKeys(thrdPickUpValue);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[9]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[9]")).sendKeys(thrdDineInValue);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[@type=\"submit\"])[3]")).click();
		
	}
}
