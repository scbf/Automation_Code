package com.w2a.PickUp;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class PickUpMethods {

	WebDriver driver;

	public PickUpMethods(WebDriver driver) {

		this.driver = driver;
	}

	public void clkOnPickUp() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement deliveryBtn = driver.findElement(By.xpath("(//div/a)[11]"));
		Actions action = new Actions(driver);
		action.moveToElement(deliveryBtn).perform();
		deliveryBtn.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div/a/div/center/div)[3]")).click();
		Thread.sleep(5000);
	}

	public void clkOnSettingsBtn(String email, String orderTime, String orderPerInterval, String orderDays, String minimumOrder)
			throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-1000)", "");
		driver.findElement(By.linkText("Settings")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='form-control form-control-solid']")).clear();
		driver.findElement(By.xpath("//input[@class='form-control form-control-solid']")).sendKeys(email);
		Thread.sleep(2000);
		boolean a = driver.findElement(By.xpath("(//input[@type='checkbox'])[1]")).isSelected();
		if (a == false) {
			driver.findElement(By.xpath("(//input[@type='checkbox'])[1]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[1]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[1]"))
				.sendKeys(orderTime);
		Thread.sleep(2000);
		boolean b = driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).isSelected();
		if (b == false) {
			driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[2]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[2]"))
				.sendKeys(orderPerInterval);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[3]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[3]"))
				.sendKeys(orderDays);
		Thread.sleep(2000);
		boolean c = driver.findElement(By.xpath("(//input[@type='checkbox'])[4]")).isSelected();
		if (c == false) {
			driver.findElement(By.xpath("(//input[@type='checkbox'])[4]")).click();
		}
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[4]")).clear();
		driver.findElement(By.xpath("(//input[@class='filterme form-control form-control-solid'])[4]")).sendKeys(minimumOrder);
		Thread.sleep(5000);
	}
}