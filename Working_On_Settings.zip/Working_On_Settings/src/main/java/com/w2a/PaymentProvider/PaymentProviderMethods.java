package com.w2a.PaymentProvider;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class PaymentProviderMethods {

	WebDriver driver;

	public PaymentProviderMethods(WebDriver driver) {

		this.driver = driver;
	}

	public void gotoPaymentProvider() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement deliveryBtn = driver.findElement(By.xpath("(//div/a)[11]"));
		Actions action = new Actions(driver);
		action.moveToElement(deliveryBtn).perform();
		deliveryBtn.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div/a/div/center/div)[7]")).click();
		Thread.sleep(5000);
	}
	public void gotoBranchSelection(String branchValue) throws InterruptedException {
		
		WebElement branchSelection = driver.findElement(By.xpath("//div[@class=' css-1d8n9bt']"));
		Actions action = new Actions(driver);
		action.moveToElement(branchSelection).click().sendKeys(branchValue).sendKeys(Keys.ENTER).perform();
		Thread.sleep(3000);	
	}
	public void clkOnPaymentType() {
		
		driver.findElement(By.xpath("(//div[@class='card-body p-2'])[1]")).click();
	}
	public void enterPaymentProviderDetails(String customerID, String terminalID, String authorToken) throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class=' form-control form-control-solid'])[1]")).clear();
		driver.findElement(By.xpath("(//input[@class=' form-control form-control-solid'])[1]")).sendKeys(customerID);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class=' form-control form-control-solid'])[2]")).clear();
		driver.findElement(By.xpath("(//input[@class=' form-control form-control-solid'])[2]")).sendKeys(terminalID);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//input[@class=' form-control form-control-solid'])[3]")).clear();
		driver.findElement(By.xpath("(//input[@class=' form-control form-control-solid'])[3]")).sendKeys(authorToken);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}
}
