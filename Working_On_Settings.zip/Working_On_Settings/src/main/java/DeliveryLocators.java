

public class DeliveryLocators {
	// enter the user login credentials//
	public static String email = "robertjames@gmail.com";
	public static String password = "123456";

	// user entering the restaurent times
	public static String branchName = "Vishakapatnam Branch";
	public static String openTime = "1000";
	public static String closeTime = "2100";
	public static String avgMakeTime = "15";

	// adding additional charges
	public static String mainName = "Golden";
	public static String levelName = "Golden Level One";
	public static String priceValue = "2";

	// user adding the zones
	public static String[] zoneDetails = { "5000", "150", "2", "250" };
	public static String[] newZoneDetails = { "2500", "200", "1", "300" };

	// User is adding the restaurant details
	public static String restaurantEmail = "vizagBranch@gmail.com";
	public static String orderingInterval = "15";
	public static String orderparticularTime = "50";
	public static String orderDaysAdvance = "2";

	// User is adding the payment provider
	public static String customerID = "";
	public static String terminalID = "";
	public static String authorToken = "";

	// user is adding the POSDetails - G Series
	public static String businessUnitId = "";
	public static String waiterId = "";
	public static String deliveryTable = "";
	public static String token = "";
	public static String tenderID = "";
	public static String pickUpTableId = "";
	
	// user is adding the POSDetails - K Series
	public static String clientId = "";
	public static String clinetSecret = "";
	public static String businessLocationId = "";
	public static String menuId = "";
	
	//user is adding the VAT Charges
	public static String delivery = "";
	public static String pickUp = "";
	public static String dineIn = "";
	
	//user is adding the GroupDetails
	public static String welcomeMessage = "";
	public static String emailGroup = "";
	
	
	
}