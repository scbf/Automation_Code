package com.w2a.MainTest;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.w2a.AllVariableValus;
import com.w2a.basePage;
import com.w2a.Delivery.DeliveryMethods;
import com.w2a.DineIn.DineInMethods;
import com.w2a.GroupSetUp.GroupSetUpMethods;
import com.w2a.POS.POSMethods;
import com.w2a.PaymentProvider.PaymentProviderMethods;
import com.w2a.PickUp.PickUpMethods;
import com.w2a.ProductCustomProperties.ProductCustomMethods;
import com.w2a.VatCharges.VatChargesMethods;

public class RunPage {

	public static void main(String[] args) throws InterruptedException, AWTException {

		WebDriver driver;
		driver = new ChromeDriver();
		AllVariableValus values = new AllVariableValus();
		basePage bPpage = new basePage(driver);
		DeliveryMethods DMPage = new DeliveryMethods(driver);
		DineInMethods DNPage = new DineInMethods(driver);
		PickUpMethods PMpage = new PickUpMethods(driver);
		PaymentProviderMethods payProPage = new PaymentProviderMethods(driver);
		VatChargesMethods VCPage = new VatChargesMethods(driver);
		ProductCustomMethods PCPage = new ProductCustomMethods(driver);
		POSMethods Ppage = new POSMethods(driver);
		GroupSetUpMethods GMPage = new GroupSetUpMethods(driver);
		bPpage.gotoLogin(values.email, values.password);
		
		System.out.println("You are in Delivery");
		DMPage.clkOnSettings();
		DMPage.clkOnBranchSltn(values.branchName);
		DMPage.gotoRestaurantManagement(values.openTime, values.closeTime, values.avgMakeTime);
		DMPage.gotoAdtCharges(values.mainName, values.levelName, values.priceValue);
		DMPage.addingZones(values.zone1Meter, values.zone1Minorder, values.zone1deliveryCosts,
				values.zone1NodeliveryCosts);
		DMPage.addSecondZone(values.zone2Meter, values.zone2Minorder, values.zone2deliveryCosts,
			values.zone2NodeliveryCosts);
		DMPage.clkOnSettingsBtn(values.restaurantEmail, values.orderingInterval, values.orderparticularTime,
				values.orderDaysAdvance);
		DMPage.clkOnPaymentType();
		Thread.sleep(3000);
		
		// NOW WORKING ON THE PICKUP
		System.out.println("You are in PickUp");
		PMpage.clkOnPickUp();
		DMPage.clkOnBranchSltn(values.branchName);
		DMPage.gotoRestaurantManagement(values.openTime, values.closeTime, values.avgMakeTime);
		DMPage.gotoAdtCharges(values.mainName, values.levelName, values.priceValue);
		PMpage.clkOnSettingsBtn(values.restaurantEmail, values.orderingInterval, values.orderparticularTime,
				values.orderDaysAdvance, values.minimumOrderInpickUp);
		DMPage.clkOnPaymentType();
		Thread.sleep(3000);
	
		
		// NOW WORKING ON THE DINE IN
		System.out.println("You are in Dine In");
		DNPage.clkOnDIneIn();
		DMPage.clkOnBranchSltn(values.branchName);
		DMPage.gotoRestaurantManagement(values.openTime, values.closeTime, values.avgMakeTime);
		DNPage.gotoAdditionalCharges(values.mainName, values.levelName, values.priceValue);
		DNPage.gotoDineInSettings(values.restaurantEmail);
		DMPage.clkOnPaymentType();
		Thread.sleep(3000);
		
		// NOW WE ARE ADDING THE PAYMENT PROVIDER
		System.out.println("You are in Payment Provider");
		payProPage.gotoPaymentProvider();
		payProPage.gotoBranchSelection(values.branchName);
		payProPage.clkOnPaymentType();
		payProPage.enterPaymentProviderDetails(values.customerID, values.terminalID, values.authorToken);
		Thread.sleep(3000);
		
		// NOW WE ARE ENTERING THE DETAILS OF POS
		System.out.println("You are in POS");
		Ppage.gotoPOS();
		payProPage.gotoBranchSelection(values.branchName);
		Ppage.clkOnPOSType();
		Ppage.enterPOSDetails(values.businessUnitId, values.token, values.waiterId, values.tenderID,
				values.deliveryTableNo, values.pickUpTableNo);
		Thread.sleep(3000);
		
		// NOW WE ARE ENTERING THE VAT CHARGES
		System.out.println("You are in VAT Charges");
		VCPage.clkOnVatCharges();
		payProPage.gotoBranchSelection(values.branchName);
		VCPage.enterFirstCatVatCharges(values.frstVATdelivery, values.frstVATpickUp, values.frstVATdineIn);
		VCPage.enterSecondCatVatCharges(values.secndVATdelivery, values.secndVATpickUp, values.secndVATdineIn);
		VCPage.enterThridCatVatCharges(values.thrdVATdelivery, values.thrdVATpickUp, values.thrdVATdineIn);
		Thread.sleep(3000);
		
		// NOW WE ARE RUNNING THE PRODUCT CATEGORIES
		System.out.println("You are in Product Cat");
		PCPage.gotoCustomProperties();
		PCPage.enterPropertyDetails();
		Thread.sleep(3000);
		
		// NOW WE ARE ADDING THE GROUP SETUP
		System.out.println("You are in Group SetUp");
		GMPage.clkOnGroupSetUp();
		GMPage.clkOnImage(values.imageLocation);
		GMPage.enterOnGroupSetup(values.welcomeMessage, values.emailGroup);
		
		driver.quit();
	}

}